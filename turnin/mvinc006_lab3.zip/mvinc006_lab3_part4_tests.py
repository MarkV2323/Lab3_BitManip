# Array of tests to run (in order)

# Each test contains
#   description - 
#   steps - A list of steps to perform, each step can have
#       inputs - A list of tuples for the inputs to apply at that step
#       *time - The time (in ms) to wait before continuing to the next step 
#           and before checking expected values for this step. The time should be a multiple of
#           the period of the system
#       *iterations - The number of clock ticks to wait (periods)
#       expected - The expected value at the end of this step (after the "time" has elapsed.) 
#           If this value is incorrect the test will fail early before completing.
#       * only one of these should be used
#   expected - The expected output (as a list of tuples) at the end of this test

# An example set of tests is shown below. It is important to note that these tests are not "unit tests" in 
# that they are not ran in isolation but in the order shown and the state of the device is not reset or 
# altered in between executions (unless preconditions are used).

# Our Tests (default for now)
tests = [ 
    # PINA: 11001111, PORTB: 00001100 PORTC: 11110000
    {'description': 'PINA: 0xCF => PORTB: 0x0C, PORTC: 0xF0',
    'steps': [ {'inputs': [('PINA',0xCF)], 'iterations': 1 } ],
    'expected': [('PORTB',0x0C), ('PORTC',0xF0)],
    },

    # PINA: 11110000, PORTB: 00001111 PORTC: 00000000
    {'description': 'PINA: 0xF0 => PORTB: 0x0F, PORTC: 0x00',
    'steps': [ {'inputs': [('PINA',0xF0)], 'iterations': 1 } ],
    'expected': [('PORTB',0x0F), ('PORTC',0x00)],
    },

    # PINA: 11101010, PORTB: 00001110 PORTC: 10100000
    {'description': 'PINA: 0xEA => PORTB: 0x0E, PORTC: 0xA0',
    'steps': [ {'inputs': [('PINA',0xEA)], 'iterations': 1 } ],
    'expected': [('PORTB',0x0E), ('PORTC',0xA0)],
    },
 
    ]

# What variables to watch
watch = ['main::tmpA', 'main::tmpB', 'main::tmpC']

